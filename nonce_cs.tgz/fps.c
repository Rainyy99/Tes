// fast probSAT for k-SAT with incremental break counts. usage: fps file.cnf seed cb maxsec
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#define K 5
int n,m,*cl,*nt,*crit,*un,*pos,nun,*occ,*ost,*brk;char*val;double pb[256];unsigned long long rs;
static inline unsigned long long rnd(){rs^=rs<<13;rs^=rs>>7;rs^=rs<<17;return rs;}
static inline int T(int l){return l>0?val[l]:!val[-l];}
static inline void add(int c){pos[c]=nun;un[nun++]=c;}
static inline void del(int c){int l=un[--nun];un[pos[c]]=l;pos[l]=pos[c];}
void flip(int v){int pl=val[v]?v:-v; /* literal becoming false */ val[v]^=1;
 for(int i=ost[v];i<ost[v+1];i++){int c=occ[i];int *L=cl+K*c;int lit=0;for(int k=0;k<K;k++)if(abs(L[k])==v){lit=L[k];break;}
  if(lit==pl){ /* clause lost a true literal */ nt[c]--; if(nt[c]==0){brk[v]--;add(c);crit[c]=0;}
    else if(nt[c]==1){int s=0;for(int k=0;k<K;k++){if(T(L[k])){s=abs(L[k]);break;}}crit[c]=s;brk[s]++;} }
  else { nt[c]++; if(nt[c]==1){del(c);crit[c]=v;brk[v]++;} else if(nt[c]==2){brk[crit[c]]--;crit[c]=0;} } } }
int main(int a,char**av){FILE*f=fopen(av[1],"r");rs=atoll(av[2])*0x9E3779B97F4A7C15ULL+12345;double cb=atof(av[3]);double maxs=atof(av[4]);
 char line[256];while(fgets(line,256,f)){if(line[0]=='p'){sscanf(line,"p cnf %d %d",&n,&m);break;}}
 cl=malloc(4*K*m);for(int c=0;c<m;c++){int z;for(int k=0;k<K;k++)fscanf(f,"%d",&cl[K*c+k]);fscanf(f,"%d",&z);}
 ost=calloc(n+2,4);for(int i=0;i<K*m;i++)ost[abs(cl[i])+1]++;for(int i=1;i<=n+1;i++)ost[i]+=ost[i-1];
 int*fill=calloc(n+2,4);occ=malloc(4*K*m);for(int c=0;c<m;c++)for(int k=0;k<K;k++){int x=abs(cl[K*c+k]);occ[ost[x]+fill[x]++]=c;}
 nt=calloc(m,4);crit=calloc(m,4);un=malloc(4*m);pos=malloc(4*m);brk=calloc(n+1,4);val=calloc(n+1,1);
 for(int i=0;i<256;i++)pb[i]=pow(cb,-i);
 for(int i=1;i<=n;i++)val[i]=rnd()&1;
 if(a>5){FILE*g=fopen(av[5],"r");for(int i=1;i<=n;i++)val[i]=fgetc(g)=='1';fclose(g);}
 for(int c=0;c<m;c++){int s=0;for(int k=0;k<K;k++)if(T(cl[K*c+k])){nt[c]++;s=abs(cl[K*c+k]);}if(!nt[c])add(c);else if(nt[c]==1){crit[c]=s;brk[s]++;}}
 long long fl=0;int best=nun;clock_t t0=clock();
 while(nun){ if(nun<best)best=nun;
  if((fl&((1<<22)-1))==0){double el=(double)(clock()-t0)/CLOCKS_PER_SEC;fprintf(stderr,"t %.0f fl %lld nun %d best %d\n",el,fl,nun,best);if(el>maxs){return 2;}}
  int c=un[rnd()%nun];double p[K],s=0;for(int k=0;k<K;k++){int b=brk[abs(cl[K*c+k])];p[k]=pb[b<255?b:255];s+=p[k];}
  double r=(rnd()>>11)*(1.0/9007199254740992.0)*s;int k=0;while(k<K-1&&r>=p[k]){r-=p[k];k++;}flip(abs(cl[K*c+k]));fl++;}
 for(int c=0;c<m;c++){int ok=0;for(int k=0;k<K;k++)if(T(cl[K*c+k]))ok=1;if(!ok){fprintf(stderr,"BUG\n");return 1;}}
 for(int i=1;i<=n;i++)putchar('0'+val[i]);putchar('\n');fprintf(stderr,"SOLVED fl %lld\n",fl);return 0;}
