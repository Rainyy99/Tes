import sys
s=open(sys.argv[2]).read().strip();cl=[list(map(int,l.split()[:-1])) for l in open(sys.argv[1]) if l.strip() and l[0] not in 'cp']
bad=sum(1 for c in cl if not any((x>0)==(s[abs(x)-1]=='1') for x in c))
print('len',len(s),'clauses',len(cl),'unsat',bad, 'OK' if bad==0 and len(s)==1536 else 'FAIL')
