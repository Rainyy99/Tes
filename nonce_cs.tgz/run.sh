#!/bin/bash
# usage: ./run.sh file.cnf [seconds]  -> writes solution.txt if solved
CNF=${1:-pf.cnf}; SEC=${2:-780}; N=$(nproc)
command -v gcc >/dev/null || sudo apt-get install -y gcc >/dev/null
gcc -O3 -march=native -o fps fps.c -lm || exit 1
rm -f sol_*.txt; CBS=(6 7 5.4 8 6.5 7.5 9 5.8)
echo "cores $N, ${SEC}s"
for i in $(seq 0 $((N-1))); do cb=${CBS[$((i%8))]}
  ./fps $CNF $((RANDOM*100+i)) $cb $SEC >sol_$i.txt 2>log_$i.txt & done
while sleep 2; do
  for i in $(seq 0 $((N-1))); do if grep -q SOLVED log_$i.txt 2>/dev/null; then
    head -1 sol_$i.txt > solution.txt; pkill -f "./fps $CNF"; python3 verify.py $CNF solution.txt; exit 0; fi; done
  [ -z "$(pgrep -f "./fps $CNF")" ] && { echo "no solution"; tail -qn1 log_*.txt | sort -k8 -n | head -3; exit 1; }
done
